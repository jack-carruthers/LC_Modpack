#### 1.1.0
- Made the buyable shotgun its own prefab instead of just using vanilla one.
     - This should hopefully fix some issues where the host was the only one who could see or interact with the shotgun.

#### 1.0.4
- Fixed white block icon and interaction bug that happens with Brutal Company Minus

#### 1.0.3
- Small fix for scan node error

#### 1.0.2
- Changes to how I register the items

#### 1.0.1
- Added terminal info for shotguns
- Fixed bought shotguns only being visible on host
- Fixed shotguns disappearing in item store when quitting to main menu and starting/loading a new game.

#### 1.0.0
- Initial release