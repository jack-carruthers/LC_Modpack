# Buyable Shotgun
Adds shotguns to the store for 700 credits (Configurable)

Report bugs [on GitHub](https://github.com/MegaPiggy/LethalCompanyBuyableShotgun/issues/new?assignees=MegaPiggy&labels=bug&projects=&template=bug_report.yml) 
or on the [modding discord forum post](https://discord.com/channels/1168655651455639582/1184406802050322442)