# Buyable Shotgun Shells
Adds shotgun shells to the store for 20 credits (Configurable)

Report bugs [on GitHub](https://github.com/MegaPiggy/LethalCompanyBuyableShotgunShells/issues/new?assignees=MegaPiggy&labels=bug&projects=&template=bug_report.yml) 
or on the [modding discord forum post](https://discord.com/channels/1168655651455639582/1184406702846656552)