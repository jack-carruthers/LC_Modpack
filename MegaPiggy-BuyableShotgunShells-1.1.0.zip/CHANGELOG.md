#### 1.1.0
- Made the buyable shells its own prefab instead of just using vanilla one.
     - This should hopefully fix some issues where the host was the only one who could see or interact with the shells.

#### 1.0.5
- Fixed white block icon and interaction bug that happens with Brutal Company Minus

#### 1.0.4
- Small fix for scan node error

#### 1.0.3
- Changes to how I register the items

#### 1.0.2
- Added terminal info for shells
- Fixed shells disappearing in item store when quitting to main menu and starting/loading a new game.

#### 1.0.1
- Renamed Shotgun shells to just Shells so that you can actually buy them if you are using BuyableShotgun too. (thanks Lars58827109 and baosjusnsiajs on twitter/x for telling me)

#### 1.0.0
- Initial release