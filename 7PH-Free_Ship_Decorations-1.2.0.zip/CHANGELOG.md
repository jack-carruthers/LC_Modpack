# v1.2.0

- Make all ship decorations available for free.
- Move the logic that limits the number of available ship decorations per rotation to another mod.

# v1.1.0

- Limit the number of ship decorations in the rotation to 1.

# v1.0.0

- Initial release.
