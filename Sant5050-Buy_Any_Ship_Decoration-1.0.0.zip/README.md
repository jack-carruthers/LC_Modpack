# UnlockAllShipDecorations
<strong>Requires: <a href="https://thunderstore.io/c/lethal-company/p/BepInEx/BepInExPack/">BepInExPack</a></strong><br>
This mod unlocks all ship decorations in the shop instead of a random selection each quota.